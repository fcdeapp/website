# 의학 교육 데이터셋 — 부분 제작본 v0.1

**완성 교과서가 아닙니다.** 53개 과목, 435개 계획 단원 중 8개 단락 초안만 작성되었습니다. 나머지 427개 단원은 미작성입니다. 의학 전문가 검수 및 교과서 원문 대조는 수행되지 않았습니다. 임상 진료에 사용하지 마십시오.

## 적용
- 기존 `bodyparts3d` 폴더와 이 폴더를 같은 앱 데이터 루트 아래 배치합니다.
- `python medical-curriculum/tools/extract_models.py bodyparts3d`로 내부 OBJ ZIP을 각각 같은 이름의 디렉터리로 풉니다.
- manifest.json → 과목 index.json → lessons/*.json 순서로 조회합니다. 미작성 단원은 학습 완료로 표시하지 않습니다.
- lesson.sceneId가 null이 아니면 scenes/index.json에서 장면을 조회하고 anatomy/concepts.json에서 FMA ID별 실제 OBJ 경로를 찾습니다.
- 각 개념에 대해 partof 메시 집합이 있으면 그 집합을, 없으면 isa 집합을 선택합니다. 동일 FJ ID는 한 번만 렌더링합니다. 원본 좌표계 유지. 모델을 개별적으로 중심 정렬하지 마십시오.
- 카메라의 unionBounds는 선택 모델 전체를 포함하는 바운딩박스로 계산합니다. view는 앱 좌표계에 맞게 구현해야 합니다. durationMs는 제안값입니다. 애니메이션 렌더러는 제공하지 않습니다.
- 장면은 정상 구조의 위치 설명용입니다. 병변, 혈류, 호흡, 세포 등의 실제 동적 모형이 아닙니다. 원본은 모든 성별·연령·변이를 포괄하지 않습니다.

## 근거와 범위
- 교육과정 분류는 계획용 통합 분류이며 전국 의대의 강의계획서 전수 대조 결과가 아닙니다.
- 국가시험 과목 범위: https://www.law.go.kr/flDownload.do?bylClsCd=110201&flSeq=153244493&gubun= (의료법 시행규칙 별표 1의3, 2025-06-20 개정 표)
- 각 과목 referenceBooksForFutureVerification는 향후 대조할 대표 참고서로, 본문 작성시 원문을 열람했다는 뜻이 아닙니다.
- 본문은 독립 작성한 교육용 초안으로 기존 교재의 복제본이 아닙니다. 기출문제는 포함하지 않았습니다.

## 모델 출처
BodyParts3D, © The Database Center for Life Science licensed under CC Attribution 4.0 International.
https://dbarchive.biosciencedbc.jp/en/bodyparts3d/lic.html
https://creativecommons.org/licenses/by/4.0/
원본 4.0 ZIP의 메시 경로 및 메타데이터를 JSON으로 변환했습니다. 메시 자체는 포함하거나 수정하지 않았습니다. 앱에서도 출처를 표시하십시오.
