"""Run with path to existing bodyparts3d directory. No model modification."""
import sys, zipfile, pathlib
base=pathlib.Path(sys.argv[1]).resolve()
for kind in ('partof','isa'):
    stem=f'{kind}_BP3D_4.0_obj_99'
    with zipfile.ZipFile(base/(stem+'.zip')) as z:
        target=base/stem
        for info in z.infolist():
            if not info.filename.lower().endswith('.obj'): continue
            p=(target/info.filename).resolve()
            if not p.is_relative_to(target.resolve()): raise ValueError('Unsafe path')
            p.parent.mkdir(parents=True,exist_ok=True)
            with z.open(info) as src, p.open('wb') as dst:
                import shutil
                shutil.copyfileobj(src,dst)
